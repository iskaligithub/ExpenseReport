import csv
from expense_report import clean_currency

def read_credit_data():
    expenses = []
    with open("credit_card.csv", newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            expenses.append(row)
        return expenses
