import csv

def read_savings(filename):
    savings = []
    with open(filename, newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            savings.append(row)
        return savings

def clean_currency(value):
    return float(value.replace('$', '').replace(',', '').strip()) if value else 0.0

def read_savings(filename):
    savings = []
    with open(filename, newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            row['balance'] = clean_currency(row.get('payment_deposit', '0'))
            savings.append(row)
    return savings
