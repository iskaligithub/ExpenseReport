import csv

def clean_currency(value):
    if not value or value.strip() == '':
        return 0.0
    return float(value.replace('$', '').replace(',', '').strip())

def read_checking_account(filename):
    transactions = []
    with open(filename, newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            row['payment_deposit'] = clean_curreny(row['payment_deposit'])
            row['balance'] = clean_currency(row['balance'])
            transactions.append(row)
        return transactions

def get_latest_balance(transactions):
    if not transactions:
        return 0.0
    return transactions[-1]['balance']
