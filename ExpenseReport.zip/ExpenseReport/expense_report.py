import csv
from collections import defaultdict
import checking_account
import savings_account
import credit_card



def clean_currency(value):
    """Remove dollar signs, commas, and handle negative values in parentheses."""
    if not value or value.strip() == '':
        return 0.0
    value = value.replace('$', '').replace(',', '').strip()
    if value.startswith('(') and value.endswith(')'):
        value = '-' + value[1:-1]  # Convert (144.35) to -144.35
    return float(value)

def read_expenses(filename):
    """Read transactions from a CSV file."""
    expenses = []
    with open(filename, newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            expenses.append({
                'date': row['date'],
                'payee': row['payee'],
                'category': row['category'],
                'payment_deposit': clean_currency(row['payment_deposit']),
                'balance': clean_currency(row['balance']),
            })
    return expenses

def generate_report(title, expenses):
    balance = 0
    payment_deposit = defaultdict(float)

    for expense in expenses:
        balance += expense['balance']
        payment_deposit[expense['category']] += expense['payment_deposit']

    print(f"\n{title}")
    print("_" * 60)
    print(f"Total Balance : ${balance:.2f}\n")
    print("Expenses by Category:")
    for category, amount in payment_deposit.items():
        print(f"{category:15}: ${amount:.2f}")

def print_summary(title, data):
    """Print a simple summary block."""
    total = sum(entry['balance'] for entry in data)
    print(f"\n{title}")
    print("-" * 40)
    print(f"Total Transactions: {len(data)}")
    print(f"Total Balance:     ${total:.2f}")

def main():
    checking = read_expenses("checking_account.csv")
    savings = read_expenses("savings_account.csv")
    credit = read_expenses("credit_card.csv")
    all_expenses = checking + savings + credit
    generate_report("Combined Expense Report", all_expenses)
    print_summary("Checking Account Summary", checking)
    print_summary("Savings Account Summary", savings)
    print_summary("Credit Card Summary", credit)
    
if __name__ == "__main__":
    main()
